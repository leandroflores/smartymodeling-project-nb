package view.panel.base.diagram.classes.entity.model;

import javax.swing.table.AbstractTableModel;

/**
 * <p>Class of View <b>TableModelParameterUML</b>.</p>
 * <p>Class responsible for defining the Table Model for the <b>Parameter UML</b> of SMartyModeling.</p>
 * @author Leandro
 */
public class TableModelParameterUML extends AbstractTableModel {

    @Override
    public int getRowCount() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getColumnCount() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
