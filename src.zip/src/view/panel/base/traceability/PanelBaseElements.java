package view.panel.base.traceability;

import controller.view.panel.base.traceability.ControllerPanelBaseElements;
import java.awt.GridBagLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JList;
import model.controller.structural.base.ControllerDiagram;
import model.controller.structural.base.ControllerProject;
import model.structural.base.Diagram;
import model.structural.base.Element;
import model.structural.base.traceability.Traceability;
import view.main.structural.ViewMenu;

/**
 * <p>Class of View <b>PanelBaseElements</b>.</p>
 * <p>Class responsible for defining a <b>Elements Base Panel</b> of SMartyModeling.</p>
 * @author Leandro
 * @since  2019-07-22
 * @see    controller.view.panel.base.traceability.ControllerPanelBaseElements
 * @see    model.structural.base.traceability.Traceability
 * @see    view.panel.base.traceability.PanelBase
 */
public final class PanelBaseElements extends PanelBase {
    private Diagram diagram;
    
    /**
     * Default constructor method of Class.
     * @param viewMenu View Menu.
     * @param traceability Traceability.
     */
    public PanelBaseElements(ViewMenu viewMenu, Traceability traceability) {
        super(viewMenu, traceability);
        this.controller = new ControllerPanelBaseElements(this);
        this.setDefaultProperties();
        this.setDiagram();
        this.addComponents();
        this.setValues();
    }
    
    @Override
    protected void setDefaultProperties() {
        this.setLayout(new GridBagLayout());
    }
    
    /**
     * Method responsible for setting the Diagram.
     */
    private void setDiagram() {
        if (!this.project.getDiagramsList().isEmpty())
            this.diagram = this.project.getDiagramsList().get(0);
    }
    
    
    @Override
    protected void addComponents() {
        this.add(this.createLabel("Diagram: "), this.createConstraints(1, 1, 0, 0));
        this.add(this.createComboBox("diagramComboBox", new ControllerProject(this.project).getDiagrams(), 150), this.createConstraints(4, 1, 1, 0));
        
        this.add(this.createLabel("Element: "), this.createConstraints(1, 1, 0, 1));
        this.add(this.createComboBox("elementComboBox", new ControllerDiagram(this.diagram).getDefaultElements(), 250), this.createConstraints(2, 1, 1, 1));
        this.add(this.createButton("addElementButton", "", "add.png"), this.createConstraints(1, 1, 3, 1));
        this.add(this.createButton("delElementButton", "", "not.png"), this.createConstraints(1, 1, 4, 1));
        
        this.createList("elementsList");
        this.add(this.getScrollPane("elementsList"), this.createConstraints(5, 10, 0, 2));
    }
    
    /**
     * Method responsible for setting the Diagram Values.
     */
    public void setValues() {
        this.updateValues();
        this.updateElementsList();
    }
    
    /**
     * Method responsible for adding a Element.
     */
    public void addElement() {
        Element element = this.getElement();
        if (!this.traceability.getElements().contains(element)) {
            this.traceability.addElement(element);
            this.updateValues();
            this.updateElementsList();
        }
    }
    
    /**
     * Method responsible for deleting a Element.
     */
    public void delElement() {
        this.traceability.removeElement((Element) this.getElementsList().getSelectedValue());
        this.updateValues();
        this.updateElementsList();
    }
    
    /**
     * Method responsible for updating the Traceability Values.
     */
    public void updateValues() {
        this.diagram = (Diagram) this.getDiagramComboBox().getSelectedItem();
        this.getElementComboBox().removeAllItems();
        for (Element element : this.diagram.getDefaultElements())
            this.getElementComboBox().addItem(element);
        this.getElementComboBox().updateUI();
    }
    
    /**
     * Method responsible for updating the Elements List.
     */
    public void updateElementsList() {
        this.getElementsList().removeAll();
        DefaultListModel model = new DefaultListModel();
        for (int i = 0; i <  this.traceability.getElements().size(); i++)
            model.addElement(this.traceability.getElements().get(i));
        this.getElementsList().setModel(model);
    }
    
    /**
     * Method responsible for returning the Element.
     * @return Element.
     */
    public Element getElement() {
        return (Element) this.getElementComboBox().getSelectedItem();
    }
    
    /**
     * Method responsible for returning the Diagram.
     * @return Diagram.
     */
    public Diagram getDiagram() {
        return this.diagram;
    }
    
    /**
     * Method responsible for returning the Diagram Combo Box.
     * @return Diagram Combo Box.
     */
    public JComboBox getDiagramComboBox() {
        return this.getComboBox("diagramComboBox");
    }
    
    /**
     * Method responsible for returning the Element Combo Box.
     * @return Element Combo Box.
     */
    public JComboBox getElementComboBox() {
        return this.getComboBox("elementComboBox");
    }
    
    /**
     * Method responsible for returning the Add Element Button.
     * @return Add Element Button.
     */
    public JButton getAddElementButton() {
        return this.getButton("addElementButton");
    }
    
    /**
     * Method responsible for returning the Del Element Button.
     * @return Del Element Button.
     */
    public JButton getDelElementButton() {
        return this.getButton("delElementButton");
    }
    
    /**
     * Method responsible for return the Elements List.
     * @return Elements List.
     */
    public JList getElementsList() {
        return this.getList("elementsList");
    }
}